package library_management_system;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class LogViewerWindow extends JFrame {
    private JTable logTable;
    private DefaultTableModel logTableModel;

    public LogViewerWindow() {
        setTitle("Log Viewer");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Log Table Setup
        String[] columns = {"Timestamp", "Action"};
        logTableModel = new DefaultTableModel(columns, 0);
        logTable = new JTable(logTableModel);

        JScrollPane scrollPane = new JScrollPane(logTable);
        add(scrollPane, BorderLayout.CENTER);

        setVisible(true);
    }

    // Add a new log entry to the table
    public void addLog(String action) {
        String timestamp = java.time.LocalDateTime.now().toString();
        logTableModel.addRow(new Object[]{timestamp, action});
    }
}
