package library_management_system;

public class FeaturedBookDecorator extends BookDecorator {

    // Constructor to accept the book to be decorated
    public FeaturedBookDecorator(Book book) {
        super(book);
    }

    // Override the displayInfo method to add "Featured" info
    @Override
    public void displayInfo() {
        decoratedBook.displayInfo();  // Display the base book info
        System.out.println("This is a featured book!");  // Add extra feature-specific info
    }
}
