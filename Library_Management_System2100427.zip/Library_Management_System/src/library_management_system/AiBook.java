



package library_management_system;

public class AiBook extends Book {
    public AiBook(int id, String title, String author) {
        super(id, title, author, "Artificial Intelligence");
    }
}
