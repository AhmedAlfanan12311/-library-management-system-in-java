package library_management_system;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class BookManagementWindow extends JFrame {
    private JTable bookTable;
    private DefaultTableModel bookTableModel;
    private JTable logTable;
    private DefaultTableModel logTableModel;
    private List<Book> bookList = new ArrayList<>();
    private BookFactory bookFactory = new BookFactory();  // Use the factory

    public BookManagementWindow() {
        setTitle("Manage Books");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Book Table Setup
        String[] bookColumns = {"ID", "Title", "Author", "Category"};
        bookTableModel = new DefaultTableModel(bookColumns, 0);
        bookTable = new JTable(bookTableModel);

        JScrollPane scrollPane = new JScrollPane(bookTable);

        // Log Table Setup
        String[] logColumns = {"Timestamp", "Action"};
        logTableModel = new DefaultTableModel(logColumns, 0);
        logTable = new JTable(logTableModel);

        JScrollPane logScrollPane = new JScrollPane(logTable);

        // Add Book Section
        JLabel titleLabel = new JLabel("Title:");
        JTextField titleField = new JTextField(20);

        JLabel authorLabel = new JLabel("Author:");
        JTextField authorField = new JTextField(20);

        JLabel categoryLabel = new JLabel("Category:");
        String[] categories = {"Software Engineering", "Management", "Artificial Intelligence"};
        JComboBox<String> categoryComboBox = new JComboBox<>(categories);

        JButton addButton = new JButton("Add Book");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String title = titleField.getText();
                String author = authorField.getText();
                String category = (String) categoryComboBox.getSelectedItem();
                addBookToTable(title, author, category);
                titleField.setText("");
                authorField.setText("");
            }
        });

        // Borrow and Return Buttons
        JButton borrowButton = new JButton("Borrow Book");
        JButton returnButton = new JButton("Return Book");

        borrowButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrowReturnAction("borrow");
            }
        });

        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                borrowReturnAction("return");
            }
        });

        // Panel for Book Details and Add Button
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.add(titleLabel);
        panel.add(titleField);
        panel.add(authorLabel);
        panel.add(authorField);
        panel.add(categoryLabel);
        panel.add(categoryComboBox);
        panel.add(new JLabel());
        panel.add(addButton);
        panel.add(borrowButton);
        panel.add(returnButton);

        // Layout
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, scrollPane, logScrollPane);
        splitPane.setDividerLocation(300);

        add(splitPane, BorderLayout.CENTER);

        // Set the log panel and user interaction
        add(panel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void addBookToTable(String title, String author, String category) {
        // Use the factory to create a new book
        Book newBook = bookFactory.createBook(category, title, author);
        bookList.add(newBook);
        bookTableModel.addRow(new Object[]{newBook.getId(), newBook.getTitle(), newBook.getAuthor(), newBook.getCategory()});
        logUserAction("Book Added: " + newBook.getTitle());
    }

    private void borrowReturnAction(String actionType) {
        // Show dialog to select a book to borrow/return
        String[] bookTitles = new String[bookList.size()];
        for (int i = 0; i < bookList.size(); i++) {
            bookTitles[i] = bookList.get(i).getTitle();
        }

        String bookTitle = (String) JOptionPane.showInputDialog(
                this, 
                "Select the book to " + actionType + ":",
                "Book Selection",
                JOptionPane.QUESTION_MESSAGE,
                null,
                bookTitles,
                bookTitles[0]
        );

        if (bookTitle != null) {
            String userName = JOptionPane.showInputDialog(this, "Enter the user name:");
            if (userName != null && !userName.isEmpty()) {
                String actionMessage = actionType.substring(0, 1).toUpperCase() + actionType.substring(1) + " Book: " + bookTitle + " by " + userName;
                logUserAction(actionMessage);
            }
        }
    }

    private void logUserAction(String action) {
        String timestamp = java.time.LocalDateTime.now().toString();
        logTableModel.addRow(new Object[]{timestamp, action});
    }

    public static void main(String[] args) {
        new BookManagementWindow();
    }

    // UserAction class for logs (could be expanded with user data, etc.)
    class UserAction {
        private String timestamp;
        private String action;

        public UserAction(String timestamp, String action) {
            this.timestamp = timestamp;
            this.action = action;
        }
    }
}

  