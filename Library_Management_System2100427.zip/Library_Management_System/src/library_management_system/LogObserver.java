package library_management_system;

public interface LogObserver {
    void update(String message);
}
