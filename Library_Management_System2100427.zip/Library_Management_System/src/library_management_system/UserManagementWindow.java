package library_management_system;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UserManagementWindow extends JFrame {
    private JTable userTable;
    private DefaultTableModel userTableModel;

    public UserManagementWindow() {
        setTitle("Manage Users");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // User Table Setup
        String[] columns = {"Username", "Role"};
        userTableModel = new DefaultTableModel(columns, 0);
        userTable = new JTable(userTableModel);

        JScrollPane scrollPane = new JScrollPane(userTable);

        // Add User Fields
        JLabel usernameLabel = new JLabel("Username:");
        JTextField usernameField = new JTextField(20);

        JLabel roleLabel = new JLabel("Role:");
        String[] roles = {"Admin", "Regular"};
        JComboBox<String> roleComboBox = new JComboBox<>(roles);

        JButton addButton = new JButton("Add User");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String role = (String) roleComboBox.getSelectedItem();
                // Simulate adding user to the system (e.g., database)
                addUserToTable(username, role);
                usernameField.setText("");
            }
        });

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(roleLabel);
        panel.add(roleComboBox);
        panel.add(new JLabel());
        panel.add(addButton);

        add(scrollPane, BorderLayout.CENTER);
        add(panel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void addUserToTable(String username, String role) {
        // Simulate adding user to the table (this would usually interact with DB)
        userTableModel.addRow(new Object[]{username, role});
    }

    public static void main(String[] args) {
        new UserManagementWindow();
    }
}
