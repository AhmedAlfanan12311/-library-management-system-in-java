package library_management_system;

import java.util.ArrayList;
import java.util.List;

public class Logger {
    private static Logger instance;
    private List<String> logs;

    private Logger() {
        logs = new ArrayList<>();
    }

    public static Logger getInstance() {
        if (instance == null) {
            instance = new Logger();
        }
        return instance;
    }

    public void log(String action) {
        String timestamp = java.time.LocalDateTime.now().toString();
        logs.add(timestamp + " - " + action);
        System.out.println(timestamp + " - " + action); // Optionally write to a file
    }

    public List<String> getLogs() {
        return logs;
    }

    public void addObserver(LoggerObserver observer) {
        observer.update("New log added");
    }

    public interface LoggerObserver {
        void update(String message);
    }
}
