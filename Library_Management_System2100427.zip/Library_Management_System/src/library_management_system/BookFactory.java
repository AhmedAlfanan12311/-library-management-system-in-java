package library_management_system;

public class BookFactory {

    private static int nextBookId = 1;  // Start the book ID from 1

    public static Book createBook(String category, String title, String author) {
        int id = nextBookId++;  // Increment ID for each new book

        switch (category) {
            case "Software Engineering":
                return new SoftwareEngineeringBook(id, title, author);
            case "Management":
                return new ManagementBook(id, title, author);
            case "Artificial Intelligence":
                return new AiBook(id, title, author);
            default:
                throw new IllegalArgumentException("Unknown category: " + category);
        }
    }
}
