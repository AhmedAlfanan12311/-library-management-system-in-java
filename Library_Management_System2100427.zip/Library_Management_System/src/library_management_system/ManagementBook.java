
package library_management_system;

public class ManagementBook extends Book {
    public ManagementBook(int id, String title, String author) {
        super(id, title, author, "Management");
    }
}
