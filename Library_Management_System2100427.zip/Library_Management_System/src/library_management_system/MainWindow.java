package library_management_system;

import javax.swing.*;

public class MainWindow extends JFrame {
    public MainWindow() {
        setTitle("Library Management System");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JMenuBar menuBar = new JMenuBar();

        // Book Menu
        JMenu bookMenu = new JMenu("Books");
        JMenuItem manageBooks = new JMenuItem("Manage Books");
        manageBooks.addActionListener(e -> new BookManagementWindow());
        bookMenu.add(manageBooks);

        // User Menu
        JMenu userMenu = new JMenu("Users");
        JMenuItem manageUsers = new JMenuItem("Manage Users");
        manageUsers.addActionListener(e -> new UserManagementWindow()); // Assuming the user management class exists
        userMenu.add(manageUsers);

        menuBar.add(bookMenu);
        menuBar.add(userMenu);
        setJMenuBar(menuBar);

        JLabel welcomeLabel = new JLabel("Welcome to the Library Management System", JLabel.CENTER);
        add(welcomeLabel);

        setVisible(true);
    }

    public static void main(String[] args) {
        // Initialize the logger instance
        Logger logger = Logger.getInstance();
        logger.log("Library Management System started");

        // Start the MainWindow
        new MainWindow();
    }
}
