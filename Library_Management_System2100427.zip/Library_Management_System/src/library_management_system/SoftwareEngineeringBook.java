
package library_management_system;

public class SoftwareEngineeringBook extends Book {
    public SoftwareEngineeringBook(int id, String title, String author) {
        super(id, title, author, "Software Engineering");
    }
}
