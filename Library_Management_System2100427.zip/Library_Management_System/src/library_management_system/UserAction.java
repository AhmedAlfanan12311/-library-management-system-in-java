
package library_management_system;
 // UserAction class for logs (could be expanded with user data, etc.)
    class UserAction {
        private String timestamp;
        private String action;

        public UserAction(String timestamp, String action) {
            this.timestamp = timestamp;
            this.action = action;
        }
    }
