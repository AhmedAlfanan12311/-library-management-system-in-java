package library_management_system;

public class LibraryProxy implements Library {
    private RealLibrary library = new RealLibrary();
    private boolean isAdmin;

    public LibraryProxy(boolean isAdmin) {
        this.isAdmin = isAdmin;
    }

    @Override
    public void borrowBook(int bookId, int userId) {
        if (isAdmin) {
            library.borrowBook(bookId, userId);
        } else {
            System.out.println("Only admins can borrow books.");
        }
    }

    @Override
    public void returnBook(int bookId, int userId) {
        if (isAdmin) {
            library.returnBook(bookId, userId);
        } else {
            System.out.println("Only admins can return books.");
        }
    }
}
