package library_management_system;

public abstract class BookDecorator extends Book {
    protected Book decoratedBook;

    // Constructor to accept the book to be decorated
    public BookDecorator(Book book) {
        super(book.getId(), book.getTitle(), book.getAuthor(), book.getCategory());
        this.decoratedBook = book;
    }

    // Abstract displayInfo method which will be implemented by each decorator
    @Override
    public abstract void displayInfo();
}
