
package library_management_system;

public interface Library {
    void borrowBook(int bookId, int userId);
    void returnBook(int bookId, int userId);
}

class RealLibrary implements Library {
    @Override
    public void borrowBook(int bookId, int userId) {
        System.out.println("Book " + bookId + " borrowed by User " + userId);
    }

    @Override
    public void returnBook(int bookId, int userId) {
        System.out.println("Book " + bookId + " returned by User " + userId);
    }
}
