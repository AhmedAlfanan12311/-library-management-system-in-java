package library_management_system;

class UserFactory {
    public static User createUser(String role, String username) {
        switch (role) {
            case "Admin":
                return new AdminUser(username);
            case "Regular":
                return new RegularUser(username);
            default:
                throw new IllegalArgumentException("Unknown role: " + role);
        }
    }
}
