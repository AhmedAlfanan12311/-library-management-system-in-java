
package library_management_system;

import java.util.ArrayList;
import java.util.List;

public class LibraryNotifier {
    private List<LogObserver> observers = new ArrayList<>();

    public void addObserver(LogObserver observer) {
        observers.add(observer);
    }

    public void removeObserver(LogObserver observer) {
        observers.remove(observer);
    }

    public void notifyObservers(String message) {
        for (LogObserver observer : observers) {
            observer.update(message);
        }
    }
}
