
package library_management_system;

class SoftwareEngineeringBook extends Book {
    public SoftwareEngineeringBook(String title, String author) {
        super(title, author);
    }

    @Override
    public void displayInfo() {
        System.out.println("Software Engineering Book: " + title + " by " + author);
    }
}
