
package library_management_system;

// LibrarySystem interface
interface LibrarySystem {
    void borrowBook(int bookId, int userId);
    void returnBook(int bookId, int userId);
}