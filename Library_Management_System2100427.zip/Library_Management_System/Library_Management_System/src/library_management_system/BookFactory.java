package library_management_system;
class BookFactory {
    public static Book createBook(String category, String title, String author) {
        switch (category) {
            case "SoftwareEngineering":
                return new SoftwareEngineeringBook(title, author);
            case "Management":
                return new ManagementBook(title, author);
                case "AiBook":
                return new AiBook(title, author);
            default:
                throw new IllegalArgumentException("Unknown category: " + category);
        }
    }
}
