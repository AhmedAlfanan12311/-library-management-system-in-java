
package library_management_system;


class AiBook extends Book {
    public AiBook(String title, String author) {
        super(title, author);
    }

    @Override
    public void displayInfo() {
        System.out.println("AiBook: " + title + " by " + author);
    }
}
