
package library_management_system;

class RegularUser extends User {
    public RegularUser(String username) {
        super(username);
    }

    @Override
    public void displayRole() {
        System.out.println("Regular User: " + username);
    }
}

